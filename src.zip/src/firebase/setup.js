// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import {getAuth,GoogleAuthProvider} from "firebase/auth"
import { getFirestore } from "firebase/firestore"
// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBLSmaRggkfODmei2e8ZgZAoJylgre7rPI",
  authDomain: "rc-2-e0968.firebaseapp.com",
  projectId: "rc-2-e0968",
  storageBucket: "rc-2-e0968.firebasestorage.app",
  messagingSenderId: "514808568951",
  appId: "1:514808568951:web:1e2b5e89354b05d0bbba72"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app)
export const googleProvider = new GoogleAuthProvider(app)
export const database = getFirestore(app)