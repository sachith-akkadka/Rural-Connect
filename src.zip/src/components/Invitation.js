import { Avatar, Button, List, ListItem, ListItemText, Paper, Typography, Box } from '@mui/material';
import { collection, deleteDoc, doc, getDocs, setDoc } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import { auth, database } from '../firebase/setup';
import { useLocation, Link } from 'react-router-dom';
import HomeIcon from '../images/home.png';  // Import Home Icon

function Invitation() {
  const location = useLocation();
  const [user, setUser] = useState([]);

  const showrequest = async () => {
    const requestRef = doc(database, "Users", `${auth.currentUser?.uid}`);
    const requestInRef = collection(requestRef, "RequestIn");
    try {
      const data = await getDocs(requestInRef);
      const filteredData = data.docs.map((doc) => ({
        ...doc.data(),
        id: doc.id
      }));
      setUser(filteredData);
    } catch (err) {
      console.log(err);
    }
  };

  const deleteReq = async (user) => {
    const userDoc = doc(database, "Users", `${auth.currentUser?.uid}`);
    const delDocument = doc(userDoc, "RequestIn", `${user.id}`);
    try {
      await deleteDoc(delDocument);
    } catch (err) {
      console.error(err);
    }
  };

  const addConnect = async (user) => {
    const acceptDoc = doc(database, "Users", `${user.id}`);
    const connectionDoc = doc(acceptDoc, "RequestIn", `${auth.currentUser.uid}`);
    try {
      await setDoc(connectionDoc, {
        designation: location.state.designation,
        username: location.state.username,
        profile_image: location.state.profile_img,
        status: "connected"
      });
    } catch (err) {
      console.error(err);
    }
  };

  const acceptReq = async (user) => {
    const acceptDoc = doc(database, "Users", `${auth.currentUser?.uid}`);
    const connectionDoc = doc(acceptDoc, "RequestIn", `${user.id}`);
    try {
      await setDoc(connectionDoc, {
        designation: user.designation,
        username: user.username,
        profile_image: user.profile_image,
        id: user.id,
        status: "connected"
      });
      addConnect(user);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    showrequest();
  }, []);

  return (
    <div style={{ padding: "20px", backgroundColor: "#F6F7F3", height: "100vh" }}>
      {/* Conditional rendering for no pending invitations */}
      {user.filter(user => user.status === "pending").length === 0 ? (
        <Box 
          sx={{
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center', 
            justifyContent: 'center', 
            minHeight: '60vh'
          }}
        >
          <Typography variant="h6" color="textSecondary" align="center" paragraph>
            <strong>No new invitations</strong>
          </Typography>
          {/* Home Link with Home Icon */}
          <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center' }}>
          <img src={HomeIcon} style={{ width: '28px', height: '28px', marginRight: '10px' }} />
            <Typography variant="body1" color="black" textDecoration="none">Go to Home</Typography>
          </Link>
        </Box>
      ) : (
        user.filter(user => user.status === "pending").map((eachUser) => {
          return (
            <Paper key={eachUser.id} style={{ marginBottom: "10px" }}>
              <List>
                <ListItem>
                  <Avatar src={eachUser.profile_image} />
                  <ListItemText primary={eachUser.username} secondary={eachUser.designation} />
                  <Button onClick={() => deleteReq(eachUser)} sx={{ color: "grey" }} size="small">
                    Ignore
                  </Button>
                  <Button onClick={() => acceptReq(eachUser)} sx={{ ml: "5px" }} variant="outlined" size="small">
                    Accept
                  </Button>
                </ListItem>
              </List>
            </Paper>
          );
        })
      )}
    </div>
  );
}

export default Invitation;
